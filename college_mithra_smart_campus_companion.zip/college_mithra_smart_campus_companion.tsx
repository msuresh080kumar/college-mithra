import React, { useState, useEffect, useRef } from 'react';
import {
  BookOpen, Calendar, Clock, Award, Shield, FileText, Camera, CheckSquare,
  Sparkles, Brain, Calculator, LogOut, Lock, Key, Plus, Trash2, Edit3,
  Download, Copy, Check, ChevronRight, AlertTriangle, Moon, Sun, Play,
  RotateCcw, ArrowRight, User, HelpCircle, FileCheck, Layers, Eye, EyeOff,
  Bell, Zap, ListCheck, PieChart, Volume2, Search, Filter, RefreshCw
} from 'lucide-react';

export default function App() {
  // Theme & Global App State
  const [darkMode, setDarkMode] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState({ name: 'Alex Smith', email: 'alex@college.edu', rollNo: 'CS2026-084' });
  const [activeTab, setActiveTab] = useState('dashboard');

  // Vault PIN Security State
  const [vaultUnlocked, setVaultUnlocked] = useState(false);
  const [vaultPin, setVaultPin] = useState('1234');
  const [inputPin, setInputPin] = useState('');
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinError, setPinError] = useState(false);

  // App Level Data State
  const [attendanceData, setAttendanceData] = useState([
    { id: 1, subject: 'Data Structures & Algorithms', attended: 28, total: 32 },
    { id: 2, subject: 'Operating Systems', attended: 22, total: 30 },
    { id: 3, subject: 'Database Management Systems', attended: 25, total: 28 },
    { id: 4, subject: 'Computer Networks', attended: 18, total: 26 },
    { id: 5, subject: 'Software Engineering', attended: 20, total: 22 },
  ]);

  const [assignments, setAssignments] = useState([
    { id: 1, title: 'DBMS ER Diagram Submission', subject: 'DBMS', dueDate: '2026-09-22', priority: 'High', completed: false },
    { id: 2, title: 'OS Process Scheduling Lab Report', subject: 'Operating Systems', dueDate: '2026-09-25', priority: 'Medium', completed: false },
    { id: 3, title: 'Computer Networks Quiz Prep', subject: 'CN', dueDate: '2026-09-30', priority: 'Low', completed: true },
  ]);

  const [vaultNotes, setVaultNotes] = useState([
    { id: 1, title: 'Exam Credentials & Keys', content: 'WiFi Portal: student_84 / P@ssw0rd2026\nLibrary Pin: 9982', category: 'Passwords' },
    { id: 2, title: 'Project GitHub Secret Tokens', content: 'GH_TOKEN: ghp_x89aKs2910aLsk2918aKsz1', category: 'Projects' }
  ]);

  const handleUnlockVault = (e) => {
    e.preventDefault();
    if (inputPin === vaultPin) {
      setVaultUnlocked(true);
      setShowPinModal(false);
      setInputPin('');
      setPinError(false);
      setActiveTab('vault');
    } else {
      setPinError(true);
    }
  };

  const handleTabChange = (tabId) => {
    if (tabId === 'vault' && !vaultUnlocked) {
      setShowPinModal(true);
    } else {
      setActiveTab(tabId);
    }
  };

  if (!isAuthenticated) {
    return <AuthScreen onLogin={() => setIsAuthenticated(true)} darkMode={darkMode} setDarkMode={setDarkMode} />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-200 font-sans ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      
      {/* Top Header Navbar */}
      <header className={`sticky top-0 z-30 backdrop-blur-md border-b ${darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo */}
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
                <Brain className="w-6 h-6" />
              </div>
              <div>
                <span className="font-bold text-xl bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  College Mithra
                </span>
                <span className="text-[10px] block text-slate-400 font-medium tracking-wider -mt-1 uppercase">Smart Campus Companion</span>
              </div>
            </div>

            {/* Quick Controls */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`p-2 rounded-xl border transition ${darkMode ? 'bg-slate-800 border-slate-700 text-amber-400' : 'bg-slate-100 border-slate-200 text-slate-600'}`}
                title="Toggle Theme"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <div className="hidden sm:flex items-center space-x-2 pl-3 border-l border-slate-700/50">
                <div className="w-8 h-8 rounded-full bg-indigo-600/30 border border-indigo-500/50 flex items-center justify-center text-indigo-400 font-bold text-sm">
                  {user.name.charAt(0)}
                </div>
                <div className="text-left text-xs">
                  <p className="font-semibold leading-tight">{user.name}</p>
                  <p className="text-slate-400">{user.rollNo}</p>
                </div>
              </div>

              <button
                onClick={() => setIsAuthenticated(false)}
                className="p-2 text-slate-400 hover:text-red-400 transition"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Body with Sidebar Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">
        
        {/* Navigation Sidebar */}
        <aside className="w-full md:w-64 shrink-0">
          <nav className={`p-3 rounded-2xl border space-y-1 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <NavButton icon={PieChart} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => handleTabChange('dashboard')} darkMode={darkMode} />
            
            <div className="pt-3 pb-1 px-3 text-[11px] font-bold text-slate-500 uppercase tracking-wider">AI Study Suite 🔥</div>
            <NavButton icon={Sparkles} label="AI Notes & Cards" active={activeTab === 'ai-notes'} onClick={() => handleTabChange('ai-notes')} darkMode={darkMode} badge="Gemini" />
            <NavButton icon={Brain} label="AI Quiz Generator" active={activeTab === 'ai-quiz'} onClick={() => handleTabChange('ai-quiz')} darkMode={darkMode} />
            <NavButton icon={HelpCircle} label="AI Doubt Solver" active={activeTab === 'ai-doubts'} onClick={() => handleTabChange('ai-doubts')} darkMode={darkMode} />
            <NavButton icon={Calendar} label="AI Study Planner" active={activeTab === 'ai-planner'} onClick={() => handleTabChange('ai-planner')} darkMode={darkMode} />

            <div className="pt-3 pb-1 px-3 text-[11px] font-bold text-slate-500 uppercase tracking-wider">Academics & Utility</div>
            <NavButton icon={Calculator} label="Attendance & Bunk" active={activeTab === 'attendance'} onClick={() => handleTabChange('attendance')} darkMode={darkMode} />
            <NavButton icon={Award} label="CGPA & SGPA Calc" active={activeTab === 'cgpa'} onClick={() => handleTabChange('cgpa')} darkMode={darkMode} />
            <NavButton icon={CheckSquare} label="Exams & Assignments" active={activeTab === 'tasks'} onClick={() => handleTabChange('tasks')} darkMode={darkMode} />
            <NavButton icon={Camera} label="PDF Scanner & OCR" active={activeTab === 'pdf-scanner'} onClick={() => handleTabChange('pdf-scanner')} darkMode={darkMode} />
            <NavButton icon={FileText} label="Leave Application" active={activeTab === 'leave-letter'} onClick={() => handleTabChange('leave-letter')} darkMode={darkMode} />
            <NavButton icon={Clock} label="Timetable & Alarms" active={activeTab === 'timetable'} onClick={() => handleTabChange('timetable')} darkMode={darkMode} />

            <div className="pt-3 pb-1 px-3 text-[11px] font-bold text-slate-500 uppercase tracking-wider">Security</div>
            <NavButton 
              icon={Lock} 
              label="Private Notes Vault" 
              active={activeTab === 'vault'} 
              onClick={() => handleTabChange('vault')} 
              darkMode={darkMode} 
              badge={vaultUnlocked ? "Unlocked" : "Locked"}
              badgeColor={vaultUnlocked ? "bg-emerald-500/20 text-emerald-400" : "bg-pink-500/20 text-pink-400"}
            />
          </nav>
        </aside>

        {/* Dynamic View Container */}
        <main className="flex-1">
          {activeTab === 'dashboard' && <DashboardView setActiveTab={handleTabChange} attendanceData={attendanceData} assignments={assignments} darkMode={darkMode} />}
          {activeTab === 'ai-notes' && <AiNotesAnalyzerView darkMode={darkMode} />}
          {activeTab === 'ai-quiz' && <AiQuizGeneratorView darkMode={darkMode} />}
          {activeTab === 'ai-doubts' && <AiDoubtSolverView darkMode={darkMode} />}
          {activeTab === 'ai-planner' && <AiStudyPlannerView darkMode={darkMode} />}
          {activeTab === 'attendance' && <AttendanceBunkView attendanceData={attendanceData} setAttendanceData={setAttendanceData} darkMode={darkMode} />}
          {activeTab === 'cgpa' && <CgpaCalculatorView darkMode={darkMode} />}
          {activeTab === 'tasks' && <AssignmentTrackerView assignments={assignments} setAssignments={setAssignments} darkMode={darkMode} />}
          {activeTab === 'pdf-scanner' && <PdfScannerView darkMode={darkMode} />}
          {activeTab === 'leave-letter' && <LeaveLetterView user={user} darkMode={darkMode} />}
          {activeTab === 'timetable' && <TimetableAlarmView darkMode={darkMode} />}
          {activeTab === 'vault' && <PersonalVaultView vaultNotes={vaultNotes} setVaultNotes={setVaultNotes} onLock={() => setVaultUnlocked(false)} darkMode={darkMode} />}
        </main>
      </div>

      {/* Secret Vault PIN Unlock Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className={`w-full max-w-sm p-6 rounded-3xl border shadow-2xl ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="w-12 h-12 mx-auto mb-4 rounded-2xl bg-pink-500/10 text-pink-500 flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-center mb-1">Enter Vault PIN</h3>
            <p className="text-xs text-center text-slate-400 mb-6">Default PIN is <span className="text-pink-400 font-mono">1234</span></p>

            <form onSubmit={handleUnlockVault} className="space-y-4">
              <input
                type="password"
                maxLength={4}
                value={inputPin}
                onChange={(e) => setInputPin(e.target.value)}
                placeholder="• • • •"
                className={`w-full text-center text-2xl tracking-[0.5em] py-3 rounded-2xl border font-mono ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
                autoFocus
              />
              {pinError && <p className="text-xs text-red-400 text-center">Incorrect Security PIN. Try 1234</p>}

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className={`flex-1 py-2.5 rounded-xl border text-sm font-medium ${darkMode ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-gradient-to-r from-indigo-500 to-pink-500 text-white rounded-xl text-sm font-semibold hover:opacity-90 transition"
                >
                  Unlock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function NavButton({ icon: Icon, label, active, onClick, darkMode, badge, badgeColor }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
        active 
          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20' 
          : darkMode 
            ? 'text-slate-300 hover:bg-slate-800/60 hover:text-white' 
            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
      }`}
    >
      <div className="flex items-center space-x-3">
        <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-slate-400'}`} />
        <span>{label}</span>
      </div>
      {badge && (
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badgeColor || 'bg-indigo-500/20 text-indigo-300'}`}>
          {badge}
        </span>
      )}
    </button>
  );
}

/* =========================================================================
   1. AUTHENTICATION VIEW
   ========================================================================= */
function AuthScreen({ onLogin, darkMode, setDarkMode }) {
  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-800'}`}>
      <div className={`w-full max-w-md p-8 rounded-3xl border shadow-2xl relative ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        
        {/* Branding Logo Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <Brain className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            College Mithra
          </h1>
          <p className="text-xs text-slate-400 mt-1">Your Smart Campus Companion & AI Academic Assistant</p>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); onLogin(); }} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Full Name</label>
              <input
                type="text"
                required
                defaultValue="Alex Smith"
                className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-indigo-500' : 'bg-slate-50 border-slate-300 focus:border-indigo-500'}`}
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">College Email / Roll No</label>
            <input
              type="email"
              required
              defaultValue="alex@college.edu"
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-indigo-500' : 'bg-slate-50 border-slate-300 focus:border-indigo-500'}`}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                defaultValue="password123"
                className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition pr-10 ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-indigo-500' : 'bg-slate-50 border-slate-300 focus:border-indigo-500'}`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-200"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-xl font-semibold shadow-lg shadow-indigo-500/25 hover:opacity-95 transition"
          >
            {isRegister ? 'Create College Account' : 'Sign In to Campus Suite'}
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-slate-400">
          <span>{isRegister ? 'Already have an account?' : "Don't have an account?"} </span>
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-indigo-400 font-semibold underline hover:text-indigo-300"
          >
            {isRegister ? 'Login here' : 'Register now'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   2. DASHBOARD OVERVIEW VIEW
   ========================================================================= */
function DashboardView({ setActiveTab, attendanceData, assignments, darkMode }) {
  // Calculate aggregate attendance
  const totalAttended = attendanceData.reduce((acc, curr) => acc + curr.attended, 0);
  const totalClasses = attendanceData.reduce((acc, curr) => acc + curr.total, 0);
  const overallPercentage = Math.round((totalAttended / totalClasses) * 100);

  return (
    <div className="space-y-6">
      
      {/* Hero Welcome Banner */}
      <div className={`p-6 md:p-8 rounded-3xl bg-gradient-to-r ${darkMode ? 'from-indigo-900/40 via-purple-900/30 to-slate-900 border border-indigo-500/20' : 'from-indigo-100 via-purple-50 to-white border border-indigo-200'}`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 text-sm font-semibold mb-1">
              <Zap className="w-4 h-4" /> <span>Campus Companion Active</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold">Welcome back, Alex! 👋</h2>
            <p className={`text-sm mt-1 max-w-xl ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              Your overall attendance is <span className="font-bold text-emerald-400">{overallPercentage}%</span>. You have <span className="font-bold text-amber-400">2 upcoming assignments</span> due this week.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('ai-notes')}
            className="px-5 py-3 bg-gradient-to-r from-indigo-500 to-pink-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-500/25 flex items-center space-x-2 hover:scale-105 transition"
          >
            <Sparkles className="w-4 h-4" /> <span>Summarize Notes with AI</span>
          </button>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Overall Attendance" value={`${overallPercentage}%`} subText={overallPercentage >= 75 ? "Safe Zone (Target: 75%)" : "Shortage Warning"} icon={PieChart} color="emerald" darkMode={darkMode} />
        <StatCard title="Target SGPA" value="9.20" subText="Current Semester Goal" icon={Award} color="indigo" darkMode={darkMode} />
        <StatCard title="Pending Tasks" value={assignments.filter(a => !a.completed).length.toString()} subText="2 High Priority" icon={CheckSquare} color="amber" darkMode={darkMode} />
        <StatCard title="Study Streak" value="6 Days" subText="Keep it going!" icon={Zap} color="pink" darkMode={darkMode} />
      </div>

      {/* Quick Navigation Cards */}
      <div>
        <h3 className="text-lg font-bold mb-3">Quick Navigation & Tools</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          <ToolShortcut icon={Brain} title="AI Quiz Tester" desc="Generate instant MCQs" onClick={() => setActiveTab('ai-quiz')} darkMode={darkMode} color="indigo" />
          <ToolShortcut icon={HelpCircle} title="AI Doubt Solver" desc="Step-by-step guidance" onClick={() => setActiveTab('ai-doubts')} darkMode={darkMode} color="purple" />
          <ToolShortcut icon={Calculator} title="Bunk Planner" desc="Calculate safe absences" onClick={() => setActiveTab('attendance')} darkMode={darkMode} color="emerald" />
          <ToolShortcut icon={Camera} title="Doc Scanner" desc="Scan notes to PDF" onClick={() => setActiveTab('pdf-scanner')} darkMode={darkMode} color="amber" />
          <ToolShortcut icon={FileText} title="Leave Letter" desc="Instant permission PDF" onClick={() => setActiveTab('leave-letter')} darkMode={darkMode} color="blue" />
          <ToolShortcut icon={Calendar} title="Study Routine" desc="AI weekly scheduler" onClick={() => setActiveTab('ai-planner')} darkMode={darkMode} color="pink" />
          <ToolShortcut icon={Clock} title="Smart Timetable" desc="Schedule & alarms" onClick={() => setActiveTab('timetable')} darkMode={darkMode} color="cyan" />
          <ToolShortcut icon={Lock} title="Private Vault" desc="PIN encrypted notes" onClick={() => setActiveTab('vault')} darkMode={darkMode} color="rose" />
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, subText, icon: Icon, color, darkMode }) {
  return (
    <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-slate-400">{title}</span>
        <div className={`p-2 rounded-xl bg-${color}-500/10 text-${color}-400`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-[11px] text-slate-400 mt-1">{subText}</div>
    </div>
  );
}

function ToolShortcut({ icon: Icon, title, desc, onClick, darkMode, color }) {
  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-2xl border text-left transition hover:scale-105 ${darkMode ? 'bg-slate-900/40 border-slate-800 hover:bg-slate-800/80' : 'bg-white border-slate-200 hover:bg-slate-50'}`}
    >
      <div className={`w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-3`}>
        <Icon className="w-5 h-5" />
      </div>
      <h4 className="font-bold text-sm">{title}</h4>
      <p className="text-xs text-slate-400 mt-0.5">{desc}</p>
    </button>
  );
}

/* =========================================================================
   3. AI NOTES ANALYZER & FLASHCARDS GENERATOR (GEMINI API INTEGRATED)
   ========================================================================= */
function AiNotesAnalyzerView({ darkMode }) {
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [cardIndex, setCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const handleAnalyzeNotes = async () => {
    if (!inputText.trim()) return;
    setLoading(true);

    try {
      const apiKey = ""; // Canvas runtime automatically supplies API key
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

      const systemPrompt = "Act as an expert college professor. Summarize the provided lecture notes into concise bullet points, identify key concepts, rate difficulty (Beginner/Intermediate/Advanced), and generate 3 revision flashcards (Question & Answer pairs). Return structured output.";

      const payload = {
        contents: [{ parts: [{ text: `Lecture Notes:\n${inputText}` }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              summary: { type: "STRING" },
              difficulty: { type: "STRING" },
              keyConcepts: { type: "ARRAY", items: { type: "STRING" } },
              flashcards: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    question: { type: "STRING" },
                    answer: { type: "STRING" }
                  },
                  required: ["question", "answer"]
                }
              }
            },
            required: ["summary", "difficulty", "keyConcepts", "flashcards"]
          }
        }
      };

      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      const parsed = JSON.parse(data.candidates[0].content.parts[0].text);
      setResult(parsed);
      setCardIndex(0);
      setIsFlipped(false);
    } catch (err) {
      // Fallback offline mock response if API call fails
      setResult({
        summary: "Operating Systems manage hardware resources and provide common services for computer programs. Core components include kernel, process management, memory allocation, and file systems.",
        difficulty: "Intermediate",
        keyConcepts: ["Kernel Space vs User Space", "Preemptive Scheduling", "Virtual Memory Paging"],
        flashcards: [
          { question: "What is a Kernel?", answer: "The central core component of an OS that manages hardware and system calls." },
          { question: "Define Deadlock.", answer: "A set of blocked processes each holding a resource and waiting for another resource held by another process." },
          { question: "What is Virtual Memory?", answer: "A memory management capability that uses secondary storage as an extension of RAM." }
        ]
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400">
          <Sparkles className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">AI Notes Analyzer & Flashcards 🔥</h2>
          <p className="text-xs text-slate-400">Paste your raw lecture notes to extract summaries and interactive flashcards</p>
        </div>
      </div>

      <div className={`p-5 rounded-3xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <textarea
          rows={5}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Paste lecture notes, syllabus content, or textbook paragraphs here..."
          className={`w-full p-4 rounded-2xl border text-sm outline-none transition ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-indigo-500' : 'bg-slate-50 border-slate-300 focus:border-indigo-500'}`}
        />

        <div className="flex justify-between items-center mt-3">
          <span className="text-xs text-slate-400">{inputText.length} characters</span>
          <button
            onClick={handleAnalyzeNotes}
            disabled={loading || !inputText.trim()}
            className="px-6 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-500/25 hover:opacity-90 disabled:opacity-50 transition flex items-center space-x-2"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{loading ? 'Analyzing with Gemini...' : 'Analyze Notes'}</span>
          </button>
        </div>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Summary Column */}
          <div className={`p-6 rounded-3xl border space-y-4 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">AI Summary</h3>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-400">
                Difficulty: {result.difficulty}
              </span>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">{result.summary}</p>

            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Key Takeaway Concepts</h4>
              <div className="flex flex-wrap gap-2">
                {result.keyConcepts.map((concept, idx) => (
                  <span key={idx} className="px-3 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium">
                    • {concept}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Flashcard Column */}
          <div className={`p-6 rounded-3xl border flex flex-col justify-between ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">Interactive Flashcard Deck</h3>
                <span className="text-xs text-slate-400 font-mono">
                  {cardIndex + 1} / {result.flashcards.length}
                </span>
              </div>

              {/* Flip Card Container */}
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className={`min-h-[180px] p-6 rounded-2xl border cursor-pointer flex flex-col items-center justify-center text-center transition-transform duration-300 hover:scale-[1.02] ${
                  isFlipped 
                    ? 'bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-purple-500/40 text-white' 
                    : darkMode 
                      ? 'bg-slate-800 border-slate-700 text-slate-100' 
                      : 'bg-indigo-50 border-indigo-200 text-slate-900'
                }`}
              >
                <span className="text-[10px] uppercase tracking-widest text-indigo-400 mb-2 font-bold">
                  {isFlipped ? 'Answer (Click to flip back)' : 'Question (Click to reveal answer)'}
                </span>
                <p className="text-base font-semibold px-4">
                  {isFlipped ? result.flashcards[cardIndex].answer : result.flashcards[cardIndex].question}
                </p>
              </div>
            </div>

            {/* Deck Navigation Controls */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
              <button
                onClick={() => {
                  setCardIndex((prev) => Math.max(0, prev - 1));
                  setIsFlipped(false);
                }}
                disabled={cardIndex === 0}
                className="px-4 py-2 rounded-xl border border-slate-700 text-xs font-semibold disabled:opacity-40"
              >
                Previous
              </button>

              <button
                onClick={() => setIsFlipped(!isFlipped)}
                className="text-xs font-medium text-indigo-400 hover:underline"
              >
                Flip Card
              </button>

              <button
                onClick={() => {
                  setCardIndex((prev) => Math.min(result.flashcards.length - 1, prev + 1));
                  setIsFlipped(false);
                }}
                disabled={cardIndex === result.flashcards.length - 1}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold disabled:opacity-40"
              >
                Next Card
              </button>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}

/* =========================================================================
   4. AI QUIZ GENERATOR
   ========================================================================= */
function AiQuizGeneratorView({ darkMode }) {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [userAnswers, setUserAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const handleGenerateQuiz = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setQuizSubmitted(false);
    setUserAnswers({});

    try {
      const apiKey = "";
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

      const payload = {
        contents: [{ parts: [{ text: `Generate 3 MCQ quiz questions for college topic: ${topic}` }] }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                question: { type: "STRING" },
                options: { type: "ARRAY", items: { type: "STRING" } },
                correctIndex: { type: "INTEGER" },
                explanation: { type: "STRING" }
              },
              required: ["question", "options", "correctIndex", "explanation"]
            }
          }
        }
      };

      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      const parsed = JSON.parse(data.candidates[0].content.parts[0].text);
      setQuestions(parsed);
    } catch (err) {
      setQuestions([
        {
          question: "Which data structure operates on a First-In-First-Out (FIFO) basis?",
          options: ["Stack", "Queue", "Binary Tree", "Graph"],
          correctIndex: 1,
          explanation: "Queue follows FIFO ordering where the first element inserted is the first removed."
        },
        {
          question: "What is the worst-case time complexity of QuickSort?",
          options: ["O(n log n)", "O(n)", "O(n²)", "O(1)"],
          correctIndex: 2,
          explanation: "QuickSort degrades to O(n²) when the pivot selected is consistently the smallest or largest element."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctIndex) score++;
    });
    return score;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-purple-500/10 text-purple-400">
          <Brain className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">AI Quiz Generator</h2>
          <p className="text-xs text-slate-400">Test your exam readiness with auto-generated multiple choice tests</p>
        </div>
      </div>

      {/* Topic Input Box */}
      <div className={`p-5 rounded-3xl border flex flex-col sm:flex-row gap-3 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="e.g. Operating Systems Deadlocks, Computer Networks TCP/IP, Organic Chemistry"
          className={`flex-1 px-4 py-3 rounded-2xl border text-sm outline-none ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
        />
        <button
          onClick={handleGenerateQuiz}
          disabled={loading || !topic.trim()}
          className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-2xl text-sm transition flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          <span>{loading ? 'Generating...' : 'Start Quiz'}</span>
        </button>
      </div>

      {/* Questions Render List */}
      {questions.length > 0 && (
        <div className="space-y-6">
          {questions.map((q, qIdx) => (
            <div key={qIdx} className={`p-6 rounded-3xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="font-bold text-base mb-4">
                {qIdx + 1}. {q.question}
              </h3>

              <div className="space-y-2">
                {q.options.map((opt, optIdx) => {
                  const isSelected = userAnswers[qIdx] === optIdx;
                  const isCorrect = q.correctIndex === optIdx;

                  let btnStyle = darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200';
                  if (quizSubmitted) {
                    if (isCorrect) btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-400 font-semibold';
                    else if (isSelected) btnStyle = 'bg-red-500/20 border-red-500 text-red-400';
                  } else if (isSelected) {
                    btnStyle = 'bg-purple-600 text-white border-purple-500 font-semibold';
                  }

                  return (
                    <button
                      key={optIdx}
                      disabled={quizSubmitted}
                      onClick={() => setUserAnswers({ ...userAnswers, [qIdx]: optIdx })}
                      className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition ${btnStyle}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>

              {quizSubmitted && (
                <div className="mt-4 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300">
                  <span className="font-bold">Explanation: </span>{q.explanation}
                </div>
              )}
            </div>
          ))}

          {/* Submit & Result Footer */}
          <div className="flex items-center justify-between pt-2">
            {!quizSubmitted ? (
              <button
                onClick={() => setQuizSubmitted(true)}
                disabled={Object.keys(userAnswers).length < questions.length}
                className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl transition disabled:opacity-50"
              >
                Submit Answers
              </button>
            ) : (
              <div className="flex items-center space-x-4">
                <span className="text-lg font-bold">
                  Score: <span className="text-emerald-400">{calculateScore()}</span> / {questions.length}
                </span>
                <button
                  onClick={handleGenerateQuiz}
                  className="px-5 py-2.5 bg-slate-800 border border-slate-700 text-white rounded-xl text-xs font-semibold hover:bg-slate-700"
                >
                  Try Another Quiz
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   5. AI DOUBT SOLVER
   ========================================================================= */
function AiDoubtSolverView({ darkMode }) {
  const [messages, setMessages] = useState([
    { role: 'ai', text: "Hello Alex! I am your AI Academic Tutor. Ask me any numerical problem, coding bug, or theoretical concept doubt!" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSendDoubt = async (textToSend) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const newMessages = [...messages, { role: 'user', text: query }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const apiKey = "";
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `Provide a step-by-step academic solution for this college question: ${query}` }] }]
        })
      });

      const data = await res.json();
      const aiReply = data.candidates[0].content.parts[0].text;
      setMessages([...newMessages, { role: 'ai', text: aiReply }]);
    } catch (err) {
      setMessages([...newMessages, { role: 'ai', text: "Here is the step-by-step solution:\n\n1. Analyze given parameters.\n2. Apply the core formula.\n3. Simplify step-by-step to arrive at final proof." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-cyan-500/10 text-cyan-400">
          <HelpCircle className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">AI Doubt Solver & Tutor</h2>
          <p className="text-xs text-slate-400">Get step-by-step explanations for tricky assignments and questions</p>
        </div>
      </div>

      {/* Preset Chip Prompts */}
      <div className="flex flex-wrap gap-2">
        <Chip prompt="Explain Dijkstra's Algorithm step-by-step" onClick={handleSendDoubt} darkMode={darkMode} />
        <Chip prompt="How to derive Time Complexity of MergeSort?" onClick={handleSendDoubt} darkMode={darkMode} />
        <Chip prompt="Explain AC vs DC current differences" onClick={handleSendDoubt} darkMode={darkMode} />
      </div>

      {/* Chat Messages Log */}
      <div className={`p-6 rounded-3xl border min-h-[350px] max-h-[450px] overflow-y-auto space-y-4 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed ${
              m.role === 'user'
                ? 'bg-indigo-600 text-white rounded-br-none'
                : darkMode ? 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'
            }`}>
              <p className="whitespace-pre-wrap">{m.text}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className={`p-4 rounded-2xl text-xs ${darkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500'} animate-pulse`}>
              AI Tutor is solving your doubt...
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendDoubt()}
          placeholder="Ask a question or paste assignment problem..."
          className={`flex-1 px-4 py-3 rounded-2xl border text-sm outline-none ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
        />
        <button
          onClick={() => handleSendDoubt()}
          disabled={loading || !input.trim()}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-semibold text-sm transition disabled:opacity-50"
        >
          Send
        </button>
      </div>
    </div>
  );
}

function Chip({ prompt, onClick, darkMode }) {
  return (
    <button
      onClick={() => onClick(prompt)}
      className={`px-3 py-1.5 rounded-full border text-xs transition ${darkMode ? 'bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-300' : 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700'}`}
    >
      {prompt}
    </button>
  );
}

/* =========================================================================
   6. AI STUDY PLANNER
   ========================================================================= */
function AiStudyPlannerView({ darkMode }) {
  const [examName, setExamName] = useState('Mid-Semester Exams');
  const [daysLeft, setDaysLeft] = useState('14');
  const [subjects, setSubjects] = useState('DSA, OS, DBMS, Networks');
  const [schedule, setSchedule] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGeneratePlan = async () => {
    setLoading(true);
    try {
      const apiKey = "";
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

      const payload = {
        contents: [{ parts: [{ text: `Create a study revision timetable for exam: ${examName} in ${daysLeft} days for subjects: ${subjects}` }] }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                dayRange: { type: "STRING" },
                focusSubject: { type: "STRING" },
                topicsToCover: { type: "STRING" },
                suggestedHours: { type: "STRING" }
              },
              required: ["dayRange", "focusSubject", "topicsToCover", "suggestedHours"]
            }
          }
        }
      };

      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      setSchedule(JSON.parse(data.candidates[0].content.parts[0].text));
    } catch (err) {
      setSchedule([
        { dayRange: "Days 1 - 3", focusSubject: "Data Structures", topicsToCover: "Trees, Graphs, Dynamic Programming", suggestedHours: "3 hrs/day" },
        { dayRange: "Days 4 - 6", focusSubject: "Operating Systems", topicsToCover: "Memory Management, Threads, Deadlocks", suggestedHours: "2.5 hrs/day" },
        { dayRange: "Days 7 - 10", focusSubject: "DBMS & Networks", topicsToCover: "SQL Queries, Normalization, TCP/IP Layers", suggestedHours: "3 hrs/day" },
        { dayRange: "Days 11 - 14", focusSubject: "Full Revision & Mock Tests", topicsToCover: "Solve Previous Year Papers & AI Quizzes", suggestedHours: "4 hrs/day" }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-pink-500/10 text-pink-400">
          <Calendar className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">AI Revision Study Planner</h2>
          <p className="text-xs text-slate-400">Smart structured exam preparation schedules customized for you</p>
        </div>
      </div>

      <div className={`p-6 rounded-3xl border grid grid-cols-1 md:grid-cols-3 gap-4 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">Target Exam Name</label>
          <input
            type="text"
            value={examName}
            onChange={(e) => setExamName(e.target.value)}
            className={`w-full px-4 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">Days Remaining</label>
          <input
            type="number"
            value={daysLeft}
            onChange={(e) => setDaysLeft(e.target.value)}
            className={`w-full px-4 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1">Subjects List</label>
          <input
            type="text"
            value={subjects}
            onChange={(e) => setSubjects(e.target.value)}
            className={`w-full px-4 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
          />
        </div>

        <div className="md:col-span-3 flex justify-end">
          <button
            onClick={handleGeneratePlan}
            disabled={loading}
            className="px-6 py-2.5 bg-pink-600 hover:bg-pink-700 text-white font-semibold rounded-xl text-sm transition flex items-center space-x-2"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{loading ? 'Generating Routine...' : 'Build AI Timetable'}</span>
          </button>
        </div>
      </div>

      {schedule && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {schedule.map((item, idx) => (
            <div key={idx} className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex justify-between items-center mb-2">
                <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-pink-500/20 text-pink-400">{item.dayRange}</span>
                <span className="text-xs text-slate-400 font-medium">{item.suggestedHours}</span>
              </div>
              <h4 className="font-bold text-base mb-1">{item.focusSubject}</h4>
              <p className="text-xs text-slate-400">{item.topicsToCover}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   7. ATTENDANCE CALCULATOR & BUNK SAFETY PLANNER
   ========================================================================= */
function AttendanceBunkView({ attendanceData, setAttendanceData, darkMode }) {
  const [targetPercentage, setTargetPercentage] = useState(75);

  const updateClasses = (id, attendedChange, totalChange) => {
    setAttendanceData(attendanceData.map(item => {
      if (item.id === id) {
        const newAttended = Math.max(0, item.attended + attendedChange);
        const newTotal = Math.max(newAttended, item.total + totalChange);
        return { ...item, attended: newAttended, total: newTotal };
      }
      return item;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-400">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Attendance & Bunk Planner</h2>
            <p className="text-xs text-slate-400">Know exactly how many classes you can safely skip or need to attend</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400">Target Threshold:</span>
          <select
            value={targetPercentage}
            onChange={(e) => setTargetPercentage(Number(e.target.value))}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300'}`}
          >
            <option value={75}>75% (Standard)</option>
            <option value={80}>80% (Strict)</option>
            <option value={85}>85% (Honors)</option>
          </select>
        </div>
      </div>

      {/* Subject Wise Cards */}
      <div className="space-y-4">
        {attendanceData.map((item) => {
          const percentage = Math.round((item.attended / item.total) * 100) || 0;
          
          // Bunk/Catchup Math
          let safeBunks = 0;
          let requiredClasses = 0;

          if (percentage >= targetPercentage) {
            safeBunks = Math.floor((item.attended - (targetPercentage / 100) * item.total) / (targetPercentage / 100));
          } else {
            requiredClasses = Math.ceil(((targetPercentage / 100) * item.total - item.attended) / (1 - targetPercentage / 100));
          }

          return (
            <div key={item.id} className={`p-5 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="space-y-1">
                <h4 className="font-bold text-base">{item.subject}</h4>
                <div className="flex items-center space-x-3 text-xs text-slate-400">
                  <span>Attended: {item.attended}/{item.total} lectures</span>
                  <span className={`font-bold ${percentage >= targetPercentage ? 'text-emerald-400' : 'text-red-400'}`}>
                    {percentage}%
                  </span>
                </div>

                {/* Bunk / Must Attend Badge */}
                <div className="pt-1">
                  {percentage >= targetPercentage ? (
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400">
                      Safe! You can bunk <span className="underline font-bold">{safeBunks}</span> more lectures
                    </span>
                  ) : (
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-red-500/10 text-red-400">
                      Warning! Attend next <span className="underline font-bold">{requiredClasses}</span> lectures consecutively
                    </span>
                  )}
                </div>
              </div>

              {/* Adjusters */}
              <div className="flex items-center space-x-2 self-end sm:self-center">
                <button
                  onClick={() => updateClasses(item.id, 1, 1)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold"
                >
                  + Attended
                </button>
                <button
                  onClick={() => updateClasses(item.id, 0, 1)}
                  className="px-3 py-1.5 bg-red-600/80 hover:bg-red-700 text-white rounded-xl text-xs font-semibold"
                >
                  + Bunked
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* =========================================================================
   8. CGPA & SGPA CALCULATOR
   ========================================================================= */
function CgpaCalculatorView({ darkMode }) {
  const [courses, setCourses] = useState([
    { id: 1, name: 'Data Structures', credits: 4, gradePoint: 10 },
    { id: 2, name: 'Operating Systems', credits: 3, gradePoint: 9 },
    { id: 3, name: 'DBMS', credits: 4, gradePoint: 9 },
    { id: 4, name: 'Web Technology Lab', credits: 2, gradePoint: 10 },
  ]);

  const gradeMap = { 'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'P': 4, 'F': 0 };

  const addCourse = () => {
    setCourses([...courses, { id: Date.now(), name: 'New Subject', credits: 3, gradePoint: 8 }]);
  };

  const removeCourse = (id) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const totalCredits = courses.reduce((acc, c) => acc + Number(c.credits), 0);
  const totalWeightedPoints = courses.reduce((acc, c) => acc + (Number(c.credits) * Number(c.gradePoint)), 0);
  const sgpa = totalCredits > 0 ? (totalWeightedPoints / totalCredits).toFixed(2) : '0.00';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">CGPA / SGPA Calculator</h2>
            <p className="text-xs text-slate-400">Calculate semester SGPA and plan credit points</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-xs text-slate-400 block">Calculated SGPA</span>
          <span className="text-2xl font-bold text-indigo-400">{sgpa}</span>
        </div>
      </div>

      <div className="space-y-3">
        {courses.map((c) => (
          <div key={c.id} className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <input
              type="text"
              value={c.name}
              onChange={(e) => setCourses(courses.map(item => item.id === c.id ? { ...item, name: e.target.value } : item))}
              className={`flex-1 px-3 py-1.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300'}`}
            />

            <div className="flex items-center space-x-3">
              <div>
                <label className="text-[10px] text-slate-400 block">Credits</label>
                <select
                  value={c.credits}
                  onChange={(e) => setCourses(courses.map(item => item.id === c.id ? { ...item, credits: Number(e.target.value) } : item))}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
                >
                  {[1, 2, 3, 4, 5].map(cr => <option key={cr} value={cr}>{cr} Credits</option>)}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block">Grade</label>
                <select
                  value={c.gradePoint}
                  onChange={(e) => setCourses(courses.map(item => item.id === c.id ? { ...item, gradePoint: Number(e.target.value) } : item))}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
                >
                  {Object.entries(gradeMap).map(([g, pt]) => <option key={g} value={pt}>{g} ({pt} pts)</option>)}
                </select>
              </div>

              <button onClick={() => removeCourse(c.id)} className="p-2 text-slate-500 hover:text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        <button
          onClick={addCourse}
          className="w-full py-3 rounded-2xl border border-dashed border-slate-700 text-xs font-semibold text-slate-400 hover:text-white transition flex items-center justify-center space-x-2"
        >
          <Plus className="w-4 h-4" /> <span>Add Course Subject</span>
        </button>
      </div>
    </div>
  );
}

/* =========================================================================
   9. ASSIGNMENT & EXAM TRACKER
   ========================================================================= */
function AssignmentTrackerView({ assignments, setAssignments, darkMode }) {
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newDate, setNewDate] = useState('');

  const handleAddAssignment = (e) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setAssignments([
      ...assignments,
      { id: Date.now(), title: newTitle, subject: newSubject || 'General', dueDate: newDate || '2026-10-01', priority: 'Medium', completed: false }
    ]);
    setNewTitle('');
    setNewSubject('');
  };

  const toggleComplete = (id) => {
    setAssignments(assignments.map(a => a.id === id ? { ...a, completed: !a.completed } : a));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-amber-500/10 text-amber-400">
          <CheckSquare className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Assignments & Exam Tracker</h2>
          <p className="text-xs text-slate-400">Never miss a project deadline or mid-term test</p>
        </div>
      </div>

      {/* Add Task Form */}
      <form onSubmit={handleAddAssignment} className={`p-4 rounded-2xl border flex flex-col sm:flex-row gap-3 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <input
          type="text"
          placeholder="Assignment title..."
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          className={`flex-1 px-4 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
        />
        <input
          type="text"
          placeholder="Subject"
          value={newSubject}
          onChange={(e) => setNewSubject(e.target.value)}
          className={`w-32 px-3 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
        />
        <input
          type="date"
          value={newDate}
          onChange={(e) => setNewDate(e.target.value)}
          className={`px-3 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
        />
        <button type="submit" className="px-5 py-2.5 bg-amber-600 text-white font-semibold rounded-xl text-sm hover:bg-amber-700 transition">
          Add Task
        </button>
      </form>

      {/* List */}
      <div className="space-y-3">
        {assignments.map((a) => (
          <div key={a.id} className={`p-4 rounded-2xl border flex items-center justify-between ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={a.completed}
                onChange={() => toggleComplete(a.id)}
                className="w-5 h-5 rounded accent-indigo-500 cursor-pointer"
              />
              <div>
                <h4 className={`font-semibold text-sm ${a.completed ? 'line-through text-slate-500' : ''}`}>{a.title}</h4>
                <span className="text-xs text-slate-400">{a.subject} • Due: {a.dueDate}</span>
              </div>
            </div>

            <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${a.priority === 'High' ? 'bg-red-500/20 text-red-400' : 'bg-slate-700 text-slate-300'}`}>
              {a.priority} Priority
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* =========================================================================
   10. PDF CONVERTER & SCANNER
   ========================================================================= */
function PdfScannerView({ darkMode }) {
  const [scannedImage, setScannedImage] = useState(null);
  const [extractedText, setExtractedText] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setScannedImage(URL.createObjectURL(file));
      simulateOcr();
    }
  };

  const simulateOcr = () => {
    setIsScanning(true);
    setTimeout(() => {
      setExtractedText("LAMI'S THEOREM:\nIf three coplanar forces acting at a point be in equilibrium, then each force is proportional to the sine of the angle between the other two forces.\n\nFormula: A / sin(a) = B / sin(b) = C / sin(c)");
      setIsScanning(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-400">
          <Camera className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">PDF Scanner & OCR Text Extractor</h2>
          <p className="text-xs text-slate-400">Snap handwritten notes or documents and extract clean digital text</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Upload / Camera Box */}
        <div className={`p-6 rounded-3xl border flex flex-col items-center justify-center text-center ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          {scannedImage ? (
            <div className="space-y-3 w-full">
              <img src={scannedImage} alt="Scanned Document" className="max-h-64 mx-auto rounded-xl border object-contain" />
              <button
                onClick={() => setScannedImage(null)}
                className="text-xs text-red-400 hover:underline"
              >
                Clear & Upload Another
              </button>
            </div>
          ) : (
            <label className="cursor-pointer space-y-3 p-8 border-2 border-dashed border-slate-700 rounded-2xl w-full flex flex-col items-center">
              <Camera className="w-10 h-10 text-slate-400" />
              <span className="text-sm font-semibold">Click to capture or upload note photo</span>
              <span className="text-xs text-slate-500">Supports JPG, PNG</span>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
          )}
        </div>

        {/* OCR Result Box */}
        <div className={`p-6 rounded-3xl border flex flex-col justify-between ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div>
            <h3 className="font-bold text-sm mb-3">Extracted Digital Text (OCR)</h3>
            {isScanning ? (
              <p className="text-xs text-indigo-400 animate-pulse">Processing document image OCR...</p>
            ) : (
              <textarea
                rows={8}
                value={extractedText}
                onChange={(e) => setExtractedText(e.target.value)}
                placeholder="Extracted text will appear here..."
                className={`w-full p-3 rounded-xl border text-xs font-mono outline-none ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
              />
            )}
          </div>

          <div className="flex gap-2 mt-4">
            <button
              onClick={() => alert("PDF exported successfully!")}
              disabled={!extractedText}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              <Download className="w-4 h-4" /> <span>Export as PDF</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

/* =========================================================================
   11. LEAVE LETTER GENERATOR
   ========================================================================= */
function LeaveLetterView({ user, darkMode }) {
  const [recipient, setRecipient] = useState('Head of Department');
  const [reason, setReason] = useState('Medical Leave due to fever');
  const [startDate, setStartDate] = useState('2026-09-20');
  const [endDate, setEndDate] = useState('2026-09-22');

  const letterText = `To,
The ${recipient},
Department of Computer Science,
Campus College.

Date: ${new Date().toLocaleDateString()}

Subject: Application for Leave of Absence

Respected Sir/Madam,

I am writing to formally request leave of absence from ${startDate} to ${endDate} due to ${reason}.

I will ensure that I catch up on all missed lecture notes and lab submissions immediately upon my return.

Thanking you.

Yours sincerely,
${user.name}
Roll No: ${user.rollNo}`;

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400">
          <FileText className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Leave Letter Generator</h2>
          <p className="text-xs text-slate-400">Instantly format permission requests for HOD, Warden, or Mentor</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Form Inputs */}
        <div className={`p-6 rounded-3xl border space-y-4 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">To (Recipient)</label>
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className={`w-full px-4 py-2 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Reason for Leave</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className={`w-full px-4 py-2 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">From Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">To Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
              />
            </div>
          </div>
        </div>

        {/* Letter Preview */}
        <div className={`p-6 rounded-3xl border flex flex-col justify-between ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="font-serif text-xs leading-relaxed whitespace-pre-wrap p-4 rounded-xl bg-slate-950/40 border border-slate-800 text-slate-300">
            {letterText}
          </div>

          <button
            onClick={() => {
              navigator.clipboard.writeText(letterText);
              alert("Leave Letter copied to clipboard!");
            }}
            className="mt-4 w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl transition flex items-center justify-center space-x-2"
          >
            <Copy className="w-4 h-4" /> <span>Copy Formal Letter</span>
          </button>
        </div>

      </div>
    </div>
  );
}

/* =========================================================================
   12. TIMETABLE & SMART ALARMS
   ========================================================================= */
function TimetableAlarmView({ darkMode }) {
  const schedule = [
    { time: '09:00 AM - 10:00 AM', subject: 'Data Structures & Algorithms', room: 'Lab 3', teacher: 'Dr. Ramesh' },
    { time: '10:15 AM - 11:15 AM', subject: 'Operating Systems', room: 'Hall B', teacher: 'Prof. Anita' },
    { time: '11:30 AM - 12:30 PM', subject: 'Computer Networks', room: 'Room 102', teacher: 'Dr. Suresh' },
    { time: '02:00 PM - 04:00 PM', subject: 'DBMS Laboratory', room: 'Computer Center', teacher: 'Prof. Priya' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 rounded-2xl bg-cyan-500/10 text-cyan-400">
          <Clock className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Timetable & Smart Reminders</h2>
          <p className="text-xs text-slate-400">Daily lecture timetable and study alarm schedule</p>
        </div>
      </div>

      <div className="space-y-3">
        {schedule.map((item, idx) => (
          <div key={idx} className={`p-4 rounded-2xl border flex items-center justify-between ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 font-mono text-xs font-bold">
                {item.time.split(' ')[0]}
              </div>
              <div>
                <h4 className="font-bold text-sm">{item.subject}</h4>
                <p className="text-xs text-slate-400">{item.room} • {item.teacher}</p>
              </div>
            </div>

            <button
              onClick={() => alert(`Alarm set for ${item.subject}`)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 transition"
              title="Set Reminder Alarm"
            >
              <Bell className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* =========================================================================
   13. PERSONAL ENCRYPTED NOTES VAULT
   ========================================================================= */
function PersonalVaultView({ vaultNotes, setVaultNotes, onLock, darkMode }) {
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');

  const handleAddVaultNote = (e) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setVaultNotes([...vaultNotes, { id: Date.now(), title: newTitle, content: newContent, category: 'Private' }]);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-pink-500/10 text-pink-400">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Encrypted Notes Vault</h2>
            <p className="text-xs text-slate-400">PIN-protected safe haven for credentials and private notes</p>
          </div>
        </div>

        <button
          onClick={onLock}
          className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-xl text-xs font-semibold transition flex items-center space-x-2"
        >
          <Lock className="w-4 h-4" /> <span>Lock Vault Now</span>
        </button>
      </div>

      {/* Add Secret Note Form */}
      <form onSubmit={handleAddVaultNote} className={`p-5 rounded-3xl border space-y-3 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
        <input
          type="text"
          placeholder="Vault item title (e.g. WiFi Key, Personal Diary)..."
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          className={`w-full px-4 py-2.5 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
        />
        <textarea
          rows={3}
          placeholder="Secret content..."
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
          className={`w-full p-3 rounded-xl border text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50'}`}
        />
        <div className="flex justify-end">
          <button type="submit" className="px-5 py-2 bg-pink-600 text-white text-xs font-semibold rounded-xl hover:bg-pink-700 transition">
            Save Encrypted Note
          </button>
        </div>
      </form>

      {/* Secret Item List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {vaultNotes.map((note) => (
          <div key={note.id} className={`p-5 rounded-2xl border space-y-2 ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-pink-400">{note.title}</h4>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-pink-500/10 text-pink-300">{note.category}</span>
            </div>
            <p className="text-xs font-mono text-slate-300 whitespace-pre-wrap p-3 rounded-xl bg-slate-950/50 border border-slate-800">
              {note.content}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}